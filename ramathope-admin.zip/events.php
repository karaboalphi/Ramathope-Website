<?php
session_start();
include 'db.php';
if(!isset($_SESSION['admin'])){header("Location: login.php");}
if(isset($_POST['add'])){$name=$_POST['event_name'];$date=$_POST['event_date'];$desc=$_POST['description'];
$conn->query("INSERT INTO events(event_name,event_date,description) VALUES('$name','$date','$desc')");}
if(isset($_GET['delete'])){$id=$_GET['delete'];$conn->query("DELETE FROM events WHERE id=$id");}
$events=$conn->query("SELECT * FROM events ORDER BY event_date ASC");
?>
<!DOCTYPE html><html><head><title>Manage Events</title></head><body>
<h2>Events</h2><a href="dashboard.php">Back to Dashboard</a>
<h3>Add Event</h3>
<form method="POST" action="">
<input type="text" name="event_name" placeholder="Event Name" required><br><br>
<input type="date" name="event_date" required><br><br>
<textarea name="description" placeholder="Description" required></textarea><br><br>
<input type="submit" name="add" value="Add Event">
</form>
<h3>All Events</h3>
<table border="1"><tr><th>ID</th><th>Event Name</th><th>Date</th><th>Description</th><th>Action</th></tr>
<?php while($row=$events->fetch_assoc()){ ?>
<tr><td><?php echo $row['id']; ?></td>
<td><?php echo $row['event_name']; ?></td>
<td><?php echo $row['event_date']; ?></td>
<td><?php echo $row['description']; ?></td>
<td><a href="?delete=<?php echo $row['id']; ?>">Delete</a></td></tr>
<?php } ?></table></body></html>