<?php
session_start();
include 'db.php';
if(!isset($_SESSION['admin'])){header("Location: login.php");}
if(isset($_POST['add'])){
    $fname=$_POST['first_name'];$lname=$_POST['last_name'];$subject=$_POST['subject'];
    $email=$_POST['email'];$phone=$_POST['phone'];
    $conn->query("INSERT INTO teachers(first_name,last_name,subject,email,phone) VALUES('$fname','$lname','$subject','$email','$phone')");
}
if(isset($_GET['delete'])){$id=$_GET['delete'];$conn->query("DELETE FROM teachers WHERE id=$id");}
$teachers=$conn->query("SELECT * FROM teachers");
?>
<!DOCTYPE html><html><head><title>Manage Teachers</title></head><body>
<h2>Teachers</h2><a href="dashboard.php">Back to Dashboard</a>
<h3>Add Teacher</h3>
<form method="POST" action="">
<input type="text" name="first_name" placeholder="First Name" required>
<input type="text" name="last_name" placeholder="Last Name" required>
<input type="text" name="subject" placeholder="Subject" required>
<input type="email" name="email" placeholder="Email" required>
<input type="text" name="phone" placeholder="Phone" required>
<input type="submit" name="add" value="Add Teacher">
</form>
<h3>All Teachers</h3>
<table border="1"><tr><th>ID</th><th>Name</th><th>Subject</th><th>Email</th><th>Phone</th><th>Action</th></tr>
<?php while($row=$teachers->fetch_assoc()){ ?>
<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['first_name']." ".$row['last_name']; ?></td>
<td><?php echo $row['subject']; ?></td>
<td><?php echo $row['email']; ?></td>
<td><?php echo $row['phone']; ?></td>
<td><a href="?delete=<?php echo $row['id']; ?>">Delete</a></td>
</tr><?php } ?></table></body></html>