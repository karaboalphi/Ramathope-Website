<?php
session_start();
include 'db.php';
if(!isset($_SESSION['admin'])){header("Location: login.php");}
if(isset($_POST['add'])){
    $fname=$_POST['first_name'];$lname=$_POST['last_name'];$class=$_POST['class'];
    $email=$_POST['email'];$phone=$_POST['phone'];
    $conn->query("INSERT INTO students(first_name,last_name,class,email,phone) VALUES('$fname','$lname','$class','$email','$phone')");
}
if(isset($_GET['delete'])){$id=$_GET['delete'];$conn->query("DELETE FROM students WHERE id=$id");}
$students=$conn->query("SELECT * FROM students");
?>
<!DOCTYPE html><html><head><title>Manage Students</title></head><body>
<h2>Students</h2><a href="dashboard.php">Back to Dashboard</a>
<h3>Add Student</h3>
<form method="POST" action="">
<input type="text" name="first_name" placeholder="First Name" required>
<input type="text" name="last_name" placeholder="Last Name" required>
<input type="text" name="class" placeholder="Class" required>
<input type="email" name="email" placeholder="Email" required>
<input type="text" name="phone" placeholder="Phone" required>
<input type="submit" name="add" value="Add Student">
</form>
<h3>All Students</h3>
<table border="1"><tr><th>ID</th><th>Name</th><th>Class</th><th>Email</th><th>Phone</th><th>Action</th></tr>
<?php while($row=$students->fetch_assoc()){ ?>
<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['first_name']." ".$row['last_name']; ?></td>
<td><?php echo $row['class']; ?></td>
<td><?php echo $row['email']; ?></td>
<td><?php echo $row['phone']; ?></td>
<td><a href="?delete=<?php echo $row['id']; ?>">Delete</a></td>
</tr><?php } ?></table></body></html>