<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: login.php");
}
?>
<!DOCTYPE html>
<html><head><title>Admin Dashboard - Ramathope High</title></head>
<body>
<h1>Welcome, <?php echo $_SESSION['admin']; ?>!</h1>
<ul>
<li><a href="students.php">Manage Students</a></li>
<li><a href="teachers.php">Manage Teachers</a></li>
<li><a href="announcements.php">Manage Announcements</a></li>
<li><a href="events.php">Manage Events</a></li>
<li><a href="logout.php">Logout</a></li>
</ul>
</body></html>