<?php
session_start();
include 'db.php';
if(!isset($_SESSION['admin'])){header("Location: login.php");}
if(isset($_POST['add'])){$title=$_POST['title'];$description=$_POST['description'];
$conn->query("INSERT INTO announcements(title,description) VALUES('$title','$description')");}
if(isset($_GET['delete'])){$id=$_GET['delete'];$conn->query("DELETE FROM announcements WHERE id=$id");}
$announcements=$conn->query("SELECT * FROM announcements ORDER BY date_posted DESC");
?>
<!DOCTYPE html><html><head><title>Manage Announcements</title></head><body>
<h2>Announcements</h2><a href="dashboard.php">Back to Dashboard</a>
<h3>Add Announcement</h3>
<form method="POST" action="">
<input type="text" name="title" placeholder="Title" required><br><br>
<textarea name="description" placeholder="Description" required></textarea><br><br>
<input type="submit" name="add" value="Add Announcement">
</form>
<h3>All Announcements</h3>
<table border="1"><tr><th>ID</th><th>Title</th><th>Description</th><th>Date Posted</th><th>Action</th></tr>
<?php while($row=$announcements->fetch_assoc()){ ?>
<tr><td><?php echo $row['id']; ?></td>
<td><?php echo $row['title']; ?></td>
<td><?php echo $row['description']; ?></td>
<td><?php echo $row['date_posted']; ?></td>
<td><a href="?delete=<?php echo $row['id']; ?>">Delete</a></td></tr>
<?php } ?></table></body></html>